<?php
    include"conn.php";

    $query = "SELECT * FROM halaman;";
    $sql =mysqli_query( $conn,$query);
    $no = 0;

    while($result = mysqli_fetch_assoc($sql) ) {
        echo $result["nama"];
    }

    
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <script src="js/bootstrap.bundle.min.js" ></script>
    <title> CRUD peduli lindungi </title>
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container">
          <a class="navbar-brand" href="#">
            Peduli Lindungi
       </a>
        </div>
      </nav>

      <!--judul-->
      <div class="container">
        <h1 class="mt-3">Data Pengguna</h1>
        <figure>
            <blockquote class="blockquote">
                <p>silahkan isi data dibawah ini untuk data pengguna</p>
            </blockquote>
            <figcaption class="blackquote-footer">
                Peduli Lindungi <cite title ="souce title" > create read update delete</cite>
            </figcaption>
        </figure>
          <a href="kelola.php" type="button" class="btn btn-primary">
            <i class="fa fa-plus"></i>
            Tambah Data
          </a>
          <div class="table-responsive">
            <table class="table align-middle table-bordered table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Usia</th>
                        <th>Kota</th>
                        <th>Email</th>
                        <th>Telepon</th>
                        <th>Tanggal vaksin</th>
                        <th>Foto</th>
                        <th>aksi</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>eve</td>
                        <td>17</td>
                        <td>Jogja</td>
                        <td>eve@gmail.com</td>
                        <td>08976578873</td>
                        <td>21/07/24</td>
                        <td>
                            <img src="img/images.jpg" style="width: 50px;">
                        </td>
                        <td>
                            <a href="kelola.php ubah=2" type="button" class="btn btn-success">Ubah data  </a>
                                <i class="fa fa-pencil"></i>
                            <a href="proses.php? hapus=1" type="button" class="btn btn-danger">Hapus data</a>
                                <i class="fa fa-trash"></i>
</a>
                        </td>

                    </tr>

                </tbody>
              ...
            </table>
            </div>
          </div>
      </div>

</body>
    
</html>