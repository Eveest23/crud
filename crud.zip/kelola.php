<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <script src="js/bootstrap.bundle.min.js" ></script>
    <title> CRUD peduli lindungi </title>
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            Peduli Lindungi
       </a>
        </div>
      </nav>
      <div class="container">
        <form method="POST" action="proses.php">
            <div class="mb-3 row">
                <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                 <div class="col-sm-10">
                    <input type="text" name="nama" class="form-control" id="nama">
            </div>
        </div>
        
        <div class="mb-3 row">
            <label for="usia" class="col-sm-2 col-form-label">Usia</label>
            <div class="col-sm-10">
                <input type="number" name="usia" class="form-control" id="usia">
            </div>
        </div>
        
        <div class="mb-3 row">
            <label for="kota" class="col-sm-2 col-form-label">Kota</label>
            <div class="col-sm-10">
                <input type="text" name="kota" class="form-control" id="kota">
            </div>
        </div>

        <div class="mb-3 row mt-4">
            <div class="col">
                <?php
                if(isset($_GET['ubah'])){
                    ?>

                    <button type="submit" name="aksi" value="edit" class="btn btn-primary">
                        <i class="fa fa-floppy-o"aria-hidden="true"></i>
                        simpan perubahan
                    </button>
                    <?php
                          } else{
                            ?>
                            <!-- <button type="button" type="submit"name="aksi" value="add" class="btn btn-primary">
                        <i class="fa fa-floppy-o"aria-hidden="true"></i>
                        tambahkan
                    </button> -->
                    <?php

                          }
                          ?>
        
        <div class="mb-3 row">
            <label for="email" class="col-sm-2 col-form-label" >E-mail </label>
            <div class="col-sm-10">
                <input type="email" class="form-control" id="email">
            </div>
        </div>
        
        <div class="mb-3 row">
            <label for="telepon" class="col-sm-2 col-form-label">Telepon</label>
            <div class="col-sm-10">
                <input type="tel" class="form-control" id="telepon">
            </div>
        </div>
        
        <div class="mb-3 row">
            <label for="tanggalvaksin" class="col-sm-2 col-form-label">Tanggal vaksin</label>
            <div class="col-sm-10">
                <input type="date" class="form-control" id="tanggalvaksin">
            </div>
        <div class="mb-3 row">
            <label for="formFile" class="form-label">Foto</label>
                <input class="form-control" type="file" id="formFile">
            </div>
        <div class="mb-3 row">
            <button type="button" class="btn btn-primary" style="width: 110px;">tambahkan </button>
            <a href="index.php" type="button" class="btn btn-danger" style="width: 110px;">Kembali</a>
                <i class="fa fa-step-backward" aria-hidden="true" ></i> </button>

    

    
     
        </div>
       
       </form> 
            
                    </div>
    </div> 

      
</body>
    
</html>