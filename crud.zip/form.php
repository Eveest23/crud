<?php
    if(isset($_POST["aksi"])){
        echo"tambah data" <a href="index.php"> [home] </a>" ;
    }else if($_POST['aksi'] == "edit"){
        echo "edit data" <a href="index.php"> [home] </a>";
    }

    if (isset($_GET['hapus'])){
        echo "hapus data" <a href="index.php" > [home] </a>";
    }
    
    ?>